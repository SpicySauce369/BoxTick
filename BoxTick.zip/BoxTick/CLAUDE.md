# BoxTick — 작업 지침

포켓몬카드 시세 조회 + 커뮤니티 사이트. **대학 웹 프로그래밍 과제**이며 GPT와 Claude가 함께 개발한다.

## 작업 시작 전 반드시 읽을 것
1. `docs/웹사이트기획.MD`, `docs/웹사이트설계.MD`, `docs/웹사이트디자인.MD`: 기본 설계
2. `docs/추가합의사항.MD`: 최신 합의. **기존 3개 MD와 충돌하면 이 문서가 우선한다.**

상세 결정사항은 `docs/추가합의사항.MD` 한 곳에서만 관리한다. 이 파일에 복제하지 않는다.

## 핵심 규칙
- **필수 기능 우선**: 필수 기능이 끝나기 전에는 선택 기능(포트폴리오, 시세 제보, 자동 수집, 개봉 시뮬레이터) 때문에 구조를 복잡하게 만들지 않는다.
- **외부 API 비의존**: 사이트는 SQLite만 조회한다. TCGdex는 import/seed용이고, 네이버·다나와는 호출하지 않는다. 시세는 샘플 데이터다.
- **반응형 필수**: Desktop / Tablet / Mobile 모두 지원하고, 모바일에서는 레이아웃을 재배치한다.
- **디자인**: `/styleguide.html`이 확정된 디자인 샘플이다. 페이지는 `base.css`의 primitive를 조합해 만들고, 규칙은 `docs/추가합의사항.MD` 5장을 따른다. 게임 원본 에셋은 쓰지 않는다. 상승은 빨강 ▲, 하락은 파랑 ▼로 표시한다.
- **보안 기본기**: bcrypt, 세션(httpOnly, sameSite), `requireLogin`/`requireAdmin`, 작성자 확인, prepared statement, 입력 검증, XSS 이스케이프를 지킨다.
- **테스트**: 기능을 추가할 때 `node:test` + `supertest` 테스트도 함께 작성한다.

## 실행
```
npm install
npm run db:init
npm test
npm start
```
DB 파일(`*.db`, `*.sqlite*`)과 `.env`는 커밋하지 않는다.

## Git
- 기능별 브랜치 → PR → 상대 AI 리뷰 → merge. `main`에 직접 푸시하지 않는다.
- GPT와 같은 파일을 동시에 수정하지 않는다. 담당이 겹치면 먼저 조율한다.
- 기존 `/docs` 3개 파일은 요청 없이 수정하지 않는다. 새 합의는 `docs/추가합의사항.MD`에 반영한다.
